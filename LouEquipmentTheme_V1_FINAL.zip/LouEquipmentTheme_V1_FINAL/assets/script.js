document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.menu-toggle');
  const menu = document.querySelector('.side-menu');

  if (!toggle || !menu) return;

  toggle.addEventListener('click', () => {
    toggle.classList.toggle('active');
    menu.classList.toggle('open');
  });

  menu.addEventListener('click', (event) => {
    if (event.target.matches('a')) {
      toggle.classList.remove('active');
      menu.classList.remove('open');
    }
  });
});
